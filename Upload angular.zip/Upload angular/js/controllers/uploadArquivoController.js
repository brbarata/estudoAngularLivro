angular.module("uploadArquivo").controller("UploadArquivoCtrl", function ($scope, uppercaseFilter) {

            // $scope.contatos = [];
            // $scope.operadoras = [];

            // var carregarContatos = function() {
            //  $http.get("http://localhost:3412/contatos").success(function(data) {
            //      $scope.contatos = data;
            //  }).error(function (data, status) {
                // $scope.message = "erro ao carregar contatos";
            // });
            // };

            // var carregarOperadoras = function() {
            //  $http.get("http://localhost:3412/operadoras").success(function(data) {
            //      $scope.operadoras = data;
            //  }).error(function (data, status) {
                // $scope.message = "erro ao cadastrar";
            // };

            // carregarContatos();
            // carregarOperadoras();

            // $scope.adicionarContato = function(contato) {
            // $http.post("http://localhost:3412/contatos", contato).success(function (data);
            // delete.$scope.contato;
            // carregarContatos();
            // $scope.contatos.push(angular.copy(contatos));
            // $scope.contatos.push(data);
            // });
            // }


            $scope.app = "Upload arquivo";


            // $scope.contatos = [
            //  {nome: uppercaseFilter("Pedro"), telefone: "99999999", data: new Date(),  
            //      operadora: {nome: "TIM", codigo: "41", categoria: "Celular"}
            //  },
            //  {nome: "Rafael", telefone: "55555555", data: new Date(), 
            //      operadora: {nome: "Oi", codigo: "31", categoria: "Celular"}
            //  },
            //  {nome: "Bruno", telefone: "88888888", data: new Date(), 
            //      operadora: {nome: "TIM", telefone: "31",categoria: "Celular"}
            //  },
            //  {nome: "Camila", telefone: "66666666", data: new Date(),  
            //      operadora: {nome: "Claro", codigo: "23", categoria: "Celular"}
            //  },
            //  {nome: "Igao", telefone: "77777777", data: new Date(), 
            //      operadora: {nome: "Vivo", codigo: "21", categoria: "Celular"}
            //  }
            // ]

            $scope.selecionado = "";
            $scope.negrito = "";


            // $scope.operadoras = [
            //  {nome: "TIM", codigo: "41", categoria: "Celular", preco: 2},
            //  {nome: "Vivo", codigo: "21", categoria: "Celular", preco: 3},
            //  {nome: "Claro", codigo: "23", categoria: "Celular", preco: 4},
            //  {nome: "Oi", codigo: "31", categoria: "Celular", preco: 5},
            //  {nome: "Embratel", codigo: "22", categoria: "Fixo", preco: 6}
            // ]
            $scope.adicionarContato = function(contato) {
//              $scope.contatos.push(angular.copy(contato));
//              delete $scope.contato;
                $scope.contatoForm.$setPristine();
                // console.log($scope.contatos);
            }
            $scope.limpar = function() {
//              $scope.contato.nome = "";
//              $scope.contato.telefone = "";
//              $scope.contato.operadora = "";
            }
            $scope.apagarContatos = function (contatos) {
//              $scope.contatos = contatos.filter(function (contato) {
//                  if (!contato.selecionado) return contato;
//              });
                // console.log(contatos);
            };
            $scope.isContatoSelecionado = function (contatos) {
//              return contatos.some(function (contato) {
//                  return contato.selecionado;
//              });
            // console.log(contatos);

            };

            $scope.ordenarPor = function(campo) {
                $scope.criterioDeOrdenacao = campo;
                $scope.direcaoDaOrdenacao = !$scope.direcaoDaOrdenacao;
            }
            // $scope.apagarContato = function(contatos) {
            //  // $scope.contatoForms = contatos.filter(function(contato) {
            //  //  if (!contato.selecionado) return
            //  //      contato;
            //  // });
            //  var contatosSelecionados = contatos.filter(function(contato) {
            //      if (contato.selecionado) return
            //          contato;
            //      console.log(contatosSelecionados);

            //  });
            // };

            // $scope.isContatoSelecionado = function(contatos) {
            //  var isContatoSelecionado = contatos.some(function (contato) {
            //      return contato.selecionado;
            //  });
            //  console.log(isContatoSelecionado);
            // };
    
        })  